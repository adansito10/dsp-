import {
  MatDivider,
  MatDividerModule
} from "./chunk-FN462BFY.js";
import "./chunk-75NKTDI6.js";
import "./chunk-A3AJYSFB.js";
import "./chunk-4RD3NWAN.js";
import "./chunk-ALDXYGQT.js";
import "./chunk-QUFGTQRT.js";
import "./chunk-QX2COTFA.js";
import "./chunk-S35MAB2V.js";
export {
  MatDivider,
  MatDividerModule
};

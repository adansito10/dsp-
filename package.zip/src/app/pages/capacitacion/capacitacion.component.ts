import { Component } from '@angular/core';
import { ChartConfiguration } from 'chart.js';

@Component({
  selector: 'app-capacitacion',
  standalone: false,
  templateUrl: './capacitacion.component.html',
  styleUrl: './capacitacion.component.scss'

})
export class CapacitacionComponent {

}
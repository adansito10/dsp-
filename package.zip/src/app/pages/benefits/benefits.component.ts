import { Component } from '@angular/core';

@Component({
  selector: 'app-benefits',
  standalone: false,
  templateUrl: './benefits.component.html',
  styleUrls: ['./benefits.component.scss']
})
export class BenefitsComponent { }
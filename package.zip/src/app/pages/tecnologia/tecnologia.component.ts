import { Component } from '@angular/core';

@Component({
  selector: 'app-tecnologia',
  standalone: false,
  templateUrl: './tecnologia.component.html',
  styleUrl: './tecnologia.component.scss'
})
export class TecnologiaComponent {

}
